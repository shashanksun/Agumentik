import React, { useState } from "react";
import "../App.css";

function Maldives() {
    const [isOverView,setIsOverView] = useState(false);
    const handleOverView = () => setIsOverView(true);

    
  return (
    <div>
    <div>
     
      <div className="bgi">
        <h1> Maldives</h1>

        <input type="text" id="myInput" placeholder="Type a desination"></input>
      </div>

      <div className="about">
        <h1>About Us</h1>
      </div>

      <div className="tab-view">
        <button className="button-css" onClick={handleOverView}>OVERVIEW</button>
        <button className="button-css">ITINERARY</button>
        <button className="button-css">ADDITIONAL INFO</button>
      </div>
    {isOverView &&
      <div className="oia">
        <img
          src="https://images.travelandleisureasia.com/wp-content/uploads/sites/2/2021/05/05125410/22.jpg"
          height={450}
          width={750}
        ></img>
          <h2>Package Overview</h2>
        <div className="pg">
          <p>
            Experience World-class Service at Kandima Maldives - Escape the
            ordinary Located on the largest island in Dhaalu Atoll, Kandima
            Maldives has the longest outdoor swimming pool in the Maldives, an
            abundance of water-sports, the largest beach club and tennis and
            basketball courts. It offers a marine biology centre, an art studio
            and cooking classes. Located at a 30-minute flight from Male’ and
            followed by a 20-minute boat ride to the island, the resort offers
            studios and villas with a private terrace and private pool. They
            offer endless tropical views. For fitness lovers, Kandima Maldives
            has a gym with personal trainers and provides classes like
            anti-gravity yoga, Zumba, aqua-bike classes and POUND® fitness
            lessons. Guests can hire bikes or electric scooters. Guests can
            choose among the 10 restaurants and bars the property offers. Sea
            Dragon serves authentic Chinese cuisine while Forbidden Bar plays
            live music in the night. Start the day at Aroma with fresh beverages
            and baked goods. For total relaxation, choose from massages, facials
            and a range of Signature local treatments. The Kandima Kids Club is
            run by a multilingual team of certified child care-givers. We speak
            your language! Kandima Maldives - Escape the ordinary...
          </p>
          <br />
          <div>
            <h2>Day Wise Itinerary</h2>
            <h2 className="day"> Day 1 </h2>
            <h3>ARRIVAL AT MALDIVES</h3>

            <p>
              On arrival at the Maldives International airport you will be met
              by the resort's airport representative and will be transferred to
              Vivanta By Taj Coral Reef by a speedboat ( shared basis ) .
              Afternoon free for relaxation . Overnight stay at the resort .
            </p>

            <h2 className="day"> Day 2 </h2>
            <h3> MALDIVES</h3>

            <p>
              On arrival at the Maldives International airport you will be met
              by the resort's airport representative and will be transferred to
              Vivanta By Taj Coral Reef by a speedboat ( shared basis ) .
              Afternoon free for relaxation . Overnight stay at the resort .
            </p>
            <h2 className="day"> Day 3 </h2>
            <h3> DEPATURE FROM MALDIVES</h3>

            <p>
              {" "}
              On arrival at the Maldives International airport you will be met
              by the resort's airport representative and will be transferred to
              Vivanta By Taj Coral Reef by a speedboat ( shared basis ) .
              Afternoon free for relaxation . Overnight stay at the resort .
            </p>
          </div>
          <br />
          <div>
            <h2>Additional Information</h2>
            <br />
            <h3>INCLUSIONS</h3>
            <p>4 Nights’ accommodation in selected room category</p>
            <p>Meal Plan: Full Board (Breakfast, Lunch & Dinner)</p>
            <p>Dolphin Watching Tour with Lunch, Water & Soft Drinks</p>
            <p>Snorkelling Gear & Photography</p>
            <p>In-Room 500ml Bottled Mineral Water Per Day</p>
            <br />
            <h3>EXCLUSIONS</h3>
            <p>4 Nights’ accommodation in selected room category</p>
            <p>Meal Plan: Full Board (Breakfast, Lunch & Dinner)</p>
            <p>Dolphin Watching Tour with Lunch, Water & Soft Drinks</p>
            <p>Snorkelling Gear & Photography</p>
            <p>In-Room 500ml Bottled Mineral Water Per Day</p>
          </div>
        </div>
      </div>

      }
    </div>
    
    </div>
  );
}

export default Maldives;
