import React, {useState} from 'react'
import AboutUs from './AboutUs';
import Footer from './Footer';
import Maldives from './Maldives'

function Home() {
    const [isMaldives,setISMaldives] = useState(false);
    const handleMaldives =()=> {setISMaldives(true); setIsAboutUs(false)};

    const [isAboutUs,setIsAboutUs] = useState(false);
    const handleAboutUS =()=> {setIsAboutUs(true); setISMaldives(false)};
  return (
    <div>
         <div className="topbg">
        <nav>
          <img
            src="https://www.golakshadweep.com/assets/new-theme/img/logo1.png"
            height={75}
          ></img>

          
          <button className="button-css">Find Reservations</button>
          <button className="button-css" onClick={handleMaldives} >Packages</button>
          <button className="button-css">about Laskshadweep</button>
          <button className="button-css" onClick={handleAboutUS}>About Us</button>
          <button className="button-css">Gol</button>
          <button className="button-css">Support</button>       
          <button className="button-css">Login</button>
          <button className="button-css" >Sign Up</button>
        </nav>
      </div>
     {isMaldives && <div> <Maldives></Maldives></div>}

     {isAboutUs &&<div><AboutUs></AboutUs></div>}
    </div>
  )
}

export default Home