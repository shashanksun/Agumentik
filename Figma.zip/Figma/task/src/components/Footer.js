import React from "react";
import "../App.css";
import playstoreicon from "./images/playstoreicon.png" 
import phone from "./images/Phone.png" 

export default function Footer() {
  return (
    <footer className="footer">
    <div className="footer-app-banner">
      <div>
        <h2 className="footer-app-banner-text">Download Our App</h2>
        <h5 className="footer-app-banner-text">Best travell in tha world</h5>
        <img
          className="img1"
          src={phone}
        ></img>
      </div>
      <img
        className="img"
        src={playstoreicon}
        width={300}
        height={200}
      ></img>
    </div>
    <div className="downpart">
      <h1>Gol</h1>
      <p>Lorem Ipsum is simply dummy 
text of the printing and type
setting industry.</p>
       <table>
       <tr>
          <th>Company</th>
          <th>About</th>
          <th>Contact Us</th>
        </tr>
        <tr>
          <td>Events</td>
          <td>Project</td>
          <td>abc@lorem.com</td>
        </tr>
        <tr>
          <td>Blogs</td>
          <td>Lorem</td>
          <td>India</td>
        </tr>
        <tr>
          <td>FAQ</td>
          <td>Services</td>
          </tr>
          <tr>
          <td>Join US</td>
          <td>Our Story</td>
          </tr>
       </table>
       <br/>
       <p>Copyright © 2023 GoL Travels Private Limited. All Rights Reserved.</p>
    </div>
    </footer>
  );
}
