import React from 'react'

function AboutUs() {
  return (
    <div>

        <h1 className='ab'>AboutUs</h1>
        <div className='ot'>
            <h2>Our Team</h2>
            <p> Quidam officiis similique sea ei, vel tollit indoctum </p>
            <p>efficiendi ei, at nihil tantas platonem eos. </p>
        </div>

        <div className='text'>

            <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRw_s204DFFc9qdeDwy0fduDhM1wZvzocIOJdVqzZ19hqQeNS3328I0v6GuCAf0jZnJ5_c&usqp=CAU'></img>
           
               <h2>Sebastian Bennett</h2>    
               <h3>Founder, LEad Photographer, CEO</h3>  
               <p>Lorem ipsum dolor sit amet, ut dicat euismod invidunt pro, ne his dolorum molestie reprehendunt, quo luptatum evertitur ex. Altera integre suavitate per an, alienum phaedrum te sea. Ex sea causae dolores, nam et doming dicunt feugait. Ea mel scripta aperiri postulant. Ut sed affert audire.</p>
        </div>

        <div className='text'>
            <h2>What customer’s are saying?</h2>
            <p>Take a look at what our customer’s are saying. At Nature we not only provide you with services but also we provide you with valuable experiences for your valuable time.</p>
        
       <img src='https://www.nationsonline.org/gallery/India/Tea-Gardens-Munnar-Kerala-India.jpg' height={300} width={300}></img>
       <img src='https://images.sportsnhobbies.org/kayakers-on-lake.jpg' height={300} width={300}></img>
        <img src='https://img.traveltriangle.com/blog/wp-content/uploads/2020/02/cover-Skydiving-In-Indonesia.jpg' height={300} width={300}></img>
       <img src='https://twissen.com/wp-content/uploads/2017/06/pexels-photo-238622.jpg' height={300} width={300}></img>
        </div>
        <h2>Certificate</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In id turpis sodales,
 facilisis massa at, rutrum eros.</p>
    </div>
  )
}

export default AboutUs